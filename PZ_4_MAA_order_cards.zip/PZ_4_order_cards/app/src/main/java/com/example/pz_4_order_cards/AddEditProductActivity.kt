package com.example.pz_4_order_cards

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import android.widget.Button
import android.widget.ImageView

// Экран для добавления нового товара или редактирования существующего
class AddEditProductActivity : AppCompatActivity() {

    // Это нужно, чтобы у каждого нового товара был свой уникальный номер (id)
    // Начинаем с 100, чтобы не мешать тестовым товарам (у них id от 0 до 5)
    companion object {
        private var nextId = 100
    }

    // Сюда будем сохранять ссылки на поля ввода и картинку с экрана
    private lateinit var titleInput: TextInputEditText      // поле для названия
    private lateinit var descriptionInput: TextInputEditText // поле для описания
    private lateinit var priceInput: TextInputEditText       // поле для цены
    private lateinit var productImage: ImageView             // картинка товара
    private var currentImageResId = R.drawable.photo_item_1 // текущий выбранный рисунок (по умолчанию — первый)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Включаем режим "под системные панели" (чтобы не залезало под статус-бар)
        enableEdgeToEdge()
        // Загружаем макет экрана из файла activity_add_edit_product.xml
        setContentView(R.layout.activity_add_edit_product)

        // Находим все элементы на экране по их ID
        titleInput = findViewById(R.id.titleInput)
        descriptionInput = findViewById(R.id.descriptionInput)
        priceInput = findViewById(R.id.priceInput)
        productImage = findViewById(R.id.productImage)
        val selectImageButton = findViewById<Button>(R.id.selectImageButton)
        val saveButton = findViewById<Button>(R.id.saveButton)
        val cancelButton = findViewById<Button>(R.id.cancelButton)
        val titleText = findViewById<android.widget.TextView>(R.id.titleText)

        // Проверяем: открываем ли мы этот экран для редактирования или для добавления
        val existingProduct = intent.getParcelableExtra<Product>("PRODUCT")

        if (existingProduct != null) {
            // Если передали товар — значит, редактируем
            titleText.text = "Редактировать товар"
            // Заполняем поля тем, что уже есть у товара
            titleInput.setText(existingProduct.title)
            descriptionInput.setText(existingProduct.description)
            priceInput.setText(existingProduct.price.toString())
            // Запоминаем, какая картинка у этого товара
            currentImageResId = existingProduct.imageResId
            // Показываем эту картинку на экране
            productImage.setImageResource(currentImageResId)
        } else {
            // Если товар не передали — значит, создаём новый
            titleText.text = "Новый товар"
            // Показываем картинку по умолчанию
            productImage.setImageResource(currentImageResId)
        }

        // Обработчик кнопки "Выбрать фото"
        selectImageButton.setOnClickListener {
            // Создаём намерение открыть экран выбора изображения
            val intent = Intent(this, ImagePickerActivity::class.java)
            // Запускаем его и ждём ответ (код запроса = 200)
            startActivityForResult(intent, 200)
        }

        // Обработчик кнопки "Сохранить"
        saveButton.setOnClickListener {
            // Берём текст из полей и убираем пробелы в начале и конце
            val title = titleInput.text.toString().trim()
            val description = descriptionInput.text.toString().trim()
            val priceStr = priceInput.text.toString().trim()

            // Проверяем, что обязательные поля (название и цена) не пустые
            if (title.isEmpty() || priceStr.isEmpty()) {
                // Если пустые — показываем сообщение
                Toast.makeText(this, "Заполните обязательные поля (*)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener // и выходим, ничего не сохраняя
            }

            // Пробуем превратить строку с ценой в число
            val price = priceStr.toDoubleOrNull()
            if (price == null) {
                // Если не получилось (например, ввели "abc") — показываем ошибку
                Toast.makeText(this, "Некорректная цена", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Создаём новый объект товара
            val product = Product(
                id = existingProduct?.id ?: nextId++, // если редактируем — оставляем старый id, иначе даём новый
                title = title,
                description = description,
                price = price,
                imageResId = currentImageResId // используем выбранную картинку
            )

            // Готовим ответ для главного экрана
            val result = Intent()
            result.putExtra("PRODUCT_RESULT", product) // кладём туда товар
            setResult(RESULT_OK, result) // говорим: "всё ок, вот результат"
            finish() // закрываем этот экран и возвращаемся назад
        }

        // Обработчик кнопки "Отмена"
        cancelButton.setOnClickListener {
            // Просто закрываем экран без сохранения
            finish()
        }

        // Настроим отступы под статус-бар и панель навигации
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Этот метод вызывается, когда мы возвращаемся из экрана выбора изображения
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Проверяем: это точно ответ от ImagePickerActivity?
        if (requestCode == 200 && resultCode == RESULT_OK) {
            // Берём выбранное изображение из ответа
            // Если вдруг что-то пошло не так — остаёмся на фото по умолчанию
            currentImageResId = data?.getIntExtra("SELECTED_IMAGE", R.drawable.photo_item_1)!!
            // Обновляем картинку на экране
            productImage.setImageResource(currentImageResId)
        }
    }
}