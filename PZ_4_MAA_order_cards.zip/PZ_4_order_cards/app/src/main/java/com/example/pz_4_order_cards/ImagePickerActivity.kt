package com.example.pz_4_order_cards

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

// Экран, где можно выбрать картинку для нового товара
class ImagePickerActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Включаем нормальные отступы под статус-бар
        enableEdgeToEdge()
        // Загружаем макет этого экрана (там заголовок и пустой список)
        setContentView(R.layout.activity_image_picker)

        // Создаём список картинок и названий к ним
        // Слева — номер картинки (он встроен в приложение), справа — как она будет называться
        val imageList = listOf(
            R.drawable.photo_item_1 to "Товар 1",
            R.drawable.photo_item_2 to "Товар 2",
            R.drawable.photo_item_3 to "Товар 3",
            R.drawable.photo_item_4 to "Товар 4",
            R.drawable.photo_item_5 to "Товар 5",
            R.drawable.photo_item_6 to "Товар 6",
            R.drawable.photo_item_7 to "Товар 7",
            R.drawable.photo_item_8 to "Товар 8"
        )

        // Находим список (RecyclerView) на экране
        val recyclerView = findViewById<RecyclerView>(R.id.imageRecyclerView)
        // Говорим, что он должен быть сеткой в 3 колонки
        recyclerView.layoutManager = GridLayoutManager(this, 3)

        // Создаём адаптер — это штука, которая превращает наш список в красивые карточки
        val adapter = ImageAdapter(imageList) { imageResId ->
            // Когда пользователь нажимает на картинку, срабатывает эта часть
            // Готовим "посылку" с выбранным номером картинки
            val result = Intent()
            result.putExtra("SELECTED_IMAGE", imageResId)
            // Говорим, что всё прошло успешно
            setResult(RESULT_OK, result)
            // Закрываем этот экран и возвращаемся назад
            finish()
        }

        // Подключаем адаптер к списку — и готово, картинки появятся!
        recyclerView.adapter = adapter
    }
}