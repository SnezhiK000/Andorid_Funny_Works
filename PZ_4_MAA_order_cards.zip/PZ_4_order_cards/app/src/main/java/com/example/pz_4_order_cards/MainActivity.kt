package com.example.pz_4_order_cards

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.registerForActivityResult

// Главный экран — тут показываются все товары
class MainActivity : AppCompatActivity() {

    // Тут будем хранить список всех товаров
    private var productList = mutableListOf<Product>()

    // Это "слушатель" — он ждёт, когда мы вернёмся с экрана добавления товара
    private val addProductLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Если всё прошло хорошо (нажали "Сохранить")
        if (result.resultCode == RESULT_OK) {
            // Достаём новый товар из ответа
            val newProduct = result.data?.getParcelableExtra<Product>("PRODUCT_RESULT")
            if (newProduct != null) {
                // Добавляем его в наш список
                productList.add(newProduct)
                // Говорим списку что появился новый товар
                val adapter = null
                adapter.notifyItemInserted(productList.size - 1)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Заполняем список начальными товарами (для примера)
        initTestData()

        // Находим список на экране
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        // Говорим, что хотим видеть товары в 2 колонки
        recyclerView.layoutManager = GridLayoutManager(this, 2)

        // Создаём адаптер — он превращает наш список товаров в красивые карточки
        val adapter = ProductRecyclerAdapter(productList) { product ->
            // Если нажали на карточку — открываем детали этого товара
            val intent = Intent(this, ProductDetailActivity::class.java)
            intent.putExtra("PRODUCT", product)
            startActivity(intent)
        }

        // Обработка нажатия на кнопку "Редактировать" (карандаш)
        adapter.onEditClick = { product ->
            val intent = Intent(this, AddEditProductActivity::class.java)
            intent.putExtra("PRODUCT", product)
            startActivity(intent)
        }

        // Обработка нажатия на кнопку "Удалить" (корзина)
        adapter.onDeleteClick = { position ->
            // Убираем товар из списка
            productList.removeAt(position)
            // Говорим списку: "Карточку удалили — обнови экран"
            adapter.notifyItemRemoved(position)
        }

        // Подключаем адаптер к списку
        recyclerView.adapter = adapter

        // Находим кнопку "Добавить" (плавающая розовая кнопка внизу)
        val fab = findViewById<FloatingActionButton>(R.id.fab)
        fab.setOnClickListener {
            // Открываем форму для добавления нового товара
            val intent = Intent(this, AddEditProductActivity::class.java)
            addProductLauncher.launch(intent)
        }

        // Настройка отступов под статус-бар и нижнюю панель телефона
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    // Функция, которая создаёт несколько товаров для примера
    private fun initTestData() {
        productList.clear()
        val imageIds = listOf(
            R.drawable.photo_item_1,
            R.drawable.photo_item_2,
            R.drawable.photo_item_3,
            R.drawable.photo_item_4,
            R.drawable.photo_item_5,
            R.drawable.photo_item_6
        )
        for (i in imageIds.indices) {
            productList.add(
                Product(
                    id = i,
                    title = "Товар ${i + 1}",
                    description = "Описание товара ${i + 1}. Качественный и надежный.",
                    price = (100 + i * 50.0),
                    imageResId = imageIds[i]
                )
            )
        }
    }
}

private fun Nothing?.notifyItemInserted(i: Int) {}
