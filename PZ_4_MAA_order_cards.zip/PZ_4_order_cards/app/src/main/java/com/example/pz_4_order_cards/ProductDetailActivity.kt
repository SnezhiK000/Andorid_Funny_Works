package com.example.pz_4_order_cards

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView

// Экран с подробной информацией о товаре
class ProductDetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        // Загружаем макет этого экрана (большая картинка, название, цена и описание)
        setContentView(R.layout.activity_product_detail)

        // Получаем товар, который передали из главного экрана
        val product = intent.getParcelableExtra<Product>("PRODUCT")

        // Если товар действительно передали (а не пусто)
        if (product != null) {
            // Ставим его картинку
            findViewById<ImageView>(R.id.detailImage).setImageResource(product.imageResId)
            // Пишем название
            findViewById<TextView>(R.id.detailTitle).text = product.title
            // Пишем цену (и добавляем "₽" в конце)
            findViewById<TextView>(R.id.detailPrice).text = "${product.price} ₽"
            // Пишем описание
            findViewById<TextView>(R.id.detailDescription).text = product.description
        }

        // Находим кнопку "Назад"
        findViewById<Button>(R.id.backButton).setOnClickListener {
            // И при нажатии просто закрываем этот экран
            finish()
        }

        // Делаем так, чтобы контент не залезал под статус-бар и нижнюю панель телефона
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}