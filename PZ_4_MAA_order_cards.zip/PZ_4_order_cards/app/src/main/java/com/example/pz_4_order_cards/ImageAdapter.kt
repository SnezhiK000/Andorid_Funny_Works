package com.example.pz_4_order_cards

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Адаптер для экрана выбора изображения
// Он отвечает за то, как будут выглядеть карточки с картинками в сетке
class ImageAdapter(
    // Список пар: (id изображения, название)
    // Например: (R.drawable.photo_item_1, "Товар 1")
    private val images: List<Pair<Int, String>>,
    // Функция, которая вызывается, когда пользователь нажимает на картинку
    // Она передаёт назад номер выбранного изображения (resId)
    private val onImageSelect: (Int) -> Unit
) : RecyclerView.Adapter<ImageAdapter.ImageViewHolder>() {

    // Этот метод вызывается, когда RecyclerView нужно создать новую карточку
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ImageViewHolder {
        // Берём макет одной карточки — item_image.xml
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_image, parent, false)
        // Возвращаем "держатель" этой карточки (ViewHolder)
        return ImageViewHolder(view)
    }

    // Этот метод заполняет карточку данными (картинкой и названием)
    override fun onBindViewHolder(holder: ImageViewHolder, position: Int) {
        // Достаём из списка пару: изображение и название на нужной позиции
        val (resId, name) = images[position]
        // Передаём их в карточку и добавляем обработчик нажатия
        holder.bind(resId, name) { onImageSelect(resId) }
    }

    // Сколько всего карточек нужно показать?
    override fun getItemCount() = images.size

    // Класс, который "держит" элементы одной карточки
    // Он помнит, где у нас ImageView и TextView, чтобы их можно было изменять
    class ImageViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Находим картинку и текст в макете
        private val imageView: ImageView = itemView.findViewById(R.id.imageThumb)
        private val textView: TextView = itemView.findViewById(R.id.imageName)

        // Метод, который заполняет карточку конкретными данными
        fun bind(resId: Int, name: String, onClick: () -> Unit) {
            // Устанавливаем нужную картинку в ImageView
            imageView.setImageResource(resId)
            // Устанавливаем подпись под картинкой
            textView.text = name
            // Делаем всю карточку кликабельной
            itemView.setOnClickListener { onClick() }
        }
    }
}