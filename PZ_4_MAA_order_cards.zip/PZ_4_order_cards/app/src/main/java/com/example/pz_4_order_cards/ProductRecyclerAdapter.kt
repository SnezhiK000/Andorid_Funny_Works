package com.example.pz_4_order_cards

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

// Это "мастер", который делает карточки товаров для главного экрана
class ProductRecyclerAdapter(
    // Список всех товаров, которые нужно показать
    private val products: MutableList<Product>,
    // Что делать, если нажали на саму карточку (открыть детали)
    private val onItemClick: (Product) -> Unit
) : RecyclerView.Adapter<ProductRecyclerAdapter.ProductViewHolder>() {

    // Сюда позже подключим, что делать при нажатии на "карандаш" (редактировать)
    var onEditClick: ((Product) -> Unit)? = null
    // И сюда — что делать при нажатии на "корзину" (удалить)
    var onDeleteClick: ((Int) -> Unit)? = null

    // Этот метод вызывается, когда нужно создать новую карточку
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        // Берём готовый шаблон одной карточки (item_product.xml)
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_product, parent, false)
        // И возвращаем его как "заготовку"
        return ProductViewHolder(view)
    }

    // Этот метод заполняет карточку реальными данными (фото, название, цена)
    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        // Достаём товар из списка по номеру (position) и передаём его в карточку
        holder.bind(products[position], onItemClick, onEditClick, onDeleteClick, position)
    }

    // Сколько всего карточек нужно сделать?
    override fun getItemCount() = products.size

    // Это "рабочий", который знает, где у карточки картинка, текст и кнопки
    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        // Находим все элементы внутри карточки
        private val imageView: ImageView = itemView.findViewById(R.id.imageView)
        private val titleText: TextView = itemView.findViewById(R.id.titleText)
        private val priceText: TextView = itemView.findViewById(R.id.priceText)
        private val editButton: ImageButton = itemView.findViewById(R.id.editButton)
        private val deleteButton: ImageButton = itemView.findViewById(R.id.deleteButton)

        // Метод, который заполняет карточку данными и добавляет действия на кнопки
        fun bind(
            product: Product,
            onItemClick: (Product) -> Unit,
            onEditClick: ((Product) -> Unit)?,
            onDeleteClick: ((Int) -> Unit)?,
            position: Int
        ) {
            // Ставим фото товара
            imageView.setImageResource(product.imageResId)
            // Пишем название
            titleText.text = product.title
            // Пишем цену с символом рубля
            priceText.text = "${product.price} ₽"

            // Если нажали на саму карточку — открываем детали
            itemView.setOnClickListener { onItemClick(product) }
            // Если нажали на кнопку "Редактировать" — запускаем редактирование
            editButton.setOnClickListener { onEditClick?.invoke(product) }
            // Если нажали на кнопку "Удалить" — удаляем товар по номеру
            deleteButton.setOnClickListener { onDeleteClick?.invoke(position) }
        }
    }
}