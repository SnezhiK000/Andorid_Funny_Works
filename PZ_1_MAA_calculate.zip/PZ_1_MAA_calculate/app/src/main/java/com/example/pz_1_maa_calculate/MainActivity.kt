package com.example.maa_calulate //использование пакета проетка,путь к проекту
import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() { //вход в основнйо класс входа в программу
    private lateinit var editTextNumber1: EditText //поля которые инициализируют объекты и их тип
    private lateinit var editTextNumber2: EditText
    private lateinit var textViewResult: TextView
    private lateinit var buttonAdd: Button
    private lateinit var buttonSubtract: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var buttonEquals: Button
    private lateinit var buttonClear: Button

    private var currentOperation: String? = null //хранит операцию которая выполняется
    private var number1: Double = 0.0 // тип поля для ввода числа 1
    private var number2: Double = 0.0 // тип поля для ввода числа 2 плавающая точка, удвоенное значение float

    override fun onCreate(savedInstanceState: Bundle?)  //функция для создания активити
    {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) //использование файла xml activity_main
        initViews()
        setupClickListeners()
    }

    private fun initViews() //инициализация элементов в  View (xml. они переходят по ID объекта)
    {
        editTextNumber1 = findViewById(R.id.Num1)
        editTextNumber2 = findViewById(R.id.Num2)
        textViewResult = findViewById(R.id.textViewResult)
        buttonAdd = findViewById(R.id.plus)
        buttonSubtract = findViewById(R.id.mines)
        buttonMultiply = findViewById(R.id.multiply)
        buttonDivide = findViewById(R.id.divide)
        buttonEquals = findViewById(R.id.equality)
        buttonClear = findViewById(R.id.drop)
    }

    private fun setupClickListeners() //функция отклика действий при нажатии на кнопки
    {
        buttonAdd.setOnClickListener { setOperation("+") }
        buttonSubtract.setOnClickListener { setOperation("-") }
        buttonMultiply.setOnClickListener { setOperation("*") }
        buttonDivide.setOnClickListener { setOperation(":") }

        buttonEquals.setOnClickListener { calculateResult() } // вызов функции выводящей результат
        buttonClear.setOnClickListener { clearAll() } // вызов функции очищающий поля num1 и num 2, а так-же результат
    }

    @SuppressLint("SetTextI18n") //отключение проблем инициализации
    private fun setOperation(operation: String)
    {
        if (validateInput())
        {
            currentOperation = operation //передает в новую перменную выбранную операцию
            number1 = editTextNumber1.text.toString().toDouble() //перевод текста из стркои в тип double
            number2 = editTextNumber2.text.toString().toDouble() //перевод текста из стркои в тип double
            textViewResult.text = "ヾ(*'▽'*) для вывода операции $operation , нажмите '=' " //выводит текст с опрацией
        }
    }

    @SuppressLint("SetTextI18n")
    private fun calculateResult()
    {
        if (currentOperation == null) //если не выбрана операция
        {
            showToast("Сначала выберите операцию ヾ(`ヘ´)ﾉﾞ") //текст о том что бы пользователь ввел операцию
            return
        }

        if (!validateInput()) //провекра кода на валидацию, если не успешно
        {
            return //выход из функции
        }

        number1 = editTextNumber1.text.toString().toDouble() //перевод текста в тип с плавающи йтчкой (двойной float)
        number2 = editTextNumber2.text.toString().toDouble() //перевод текста в тип с плавающи йтчкой (двойной float)

        val result = when (currentOperation) //счет операции, когда выбрана операция, запись результата в result
        {
            "+" -> number1 + number2
            "-" -> number1 - number2
            "*" -> number1 * number2
            ":" -> {
                if (number2 != 0.0)  //провекра на то, что бы число на которое будет делиться - не равно 0
                {
                    number1 / number2 // если не ноль то разделяем
                }

                else
                {
                    showToast("Σ(O_O) Вы делите на ноль, вы что!?А ну исправляйте вычисление!") //если все-тки разделили на 0
                    return
                }
            }
            else -> 0.0 //иначе 0
        }

        textViewResult.text = "(￣▽￣)ノ и ваш результат вычислений: $result" //установке текста с показом результата вычисления
    }

    private fun clearAll() //функция сброса
    {
        editTextNumber1.text.clear() //очищение поля с номером 1
        editTextNumber2.text.clear() //очищение поля с номером 2
        textViewResult.text = "( ・・)つ―●○◎- все сброшено и ждет расчета! Накорми калькулятор вычислениями!" //вывод текста в результат как результат
        currentOperation = null //сброс операции присовоением нового значения
        number1 = 0.0 //присвоение значения для ввода цифр 0
        number2 = 0.0 //присвоение значения для ввода цифр 0
    }

    private fun validateInput(): Boolean //функция на проверку заполнения
    {
        val num1Text = editTextNumber1.text.toString() //принимает текст и переводит в строковый тип при вводе чисел в поле
        val num2Text = editTextNumber2.text.toString()

        if (num1Text.isEmpty() || num2Text.isEmpty()) //проверка что оба поля под числа заняты, и если 1 или 2 не введено
        {
            showToast("Вы числа считать пришли, или пустоты вычислять? (￣□￣」)")
            return false
        }

        //далее организован блок проверки как в C#
        try//попытка перевести введеные числа в тип с плавающей точкой
        {
            num1Text.toDouble()
            num2Text.toDouble()
        }

        catch (e: NumberFormatException) //вылавливание числел с неверным форматом
        {
            showToast("(ᓀ _ᓀ) введите корректные числа...")
            return false //возвращает false
        }

        return true// если все прошло возвращает true
    }

    private fun showToast(message: String) //функция вывода строки для сообщений
    {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show() //создание текста и показ
    }
}
