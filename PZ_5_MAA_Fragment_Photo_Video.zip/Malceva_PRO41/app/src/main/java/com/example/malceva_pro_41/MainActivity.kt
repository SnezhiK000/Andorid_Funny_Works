package com.example.malceva_pro_41
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager // не обязательно, но для ясности
import android.widget.Button

class MainActivity : AppCompatActivity() {

    //Инициализирую кнопки
    private lateinit var photoButton: Button
    private lateinit var videoButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        photoButton = findViewById(R.id.saveButton)
        videoButton = findViewById(R.id.cancelButton)

        // Сразу показываю фото при запуске
        showPhotoFragment()

        // начальные цвета кнопок: "Фото" активна т.к в задании указано сразу запускать фото
        setActiveButton(isPhotoActive = true)

        // клики по кнопкам
        photoButton.setOnClickListener {
            showPhotoFragment()
            setActiveButton(true)
        }

        videoButton.setOnClickListener {
            showVideoFragment()
            setActiveButton(false)
        }
    }

    // Показывает фрагмент с фото + плавная анимация
    private fun showPhotoFragment() {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.fade_in,    // вход нового фрагмента
                android.R.anim.fade_out,   // выход старого фрагмента
                android.R.anim.fade_in,    // при возврате назад — вход
                android.R.anim.fade_out    // при возврате назад — выход
            )
            .replace(R.id.fragment_container, PhotoFragment())
            .commit()
    }

    // Показывает фрагмент с видео + плавная анимация
    private fun showVideoFragment() {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.fade_in,
                android.R.anim.fade_out,
                android.R.anim.fade_in,
                android.R.anim.fade_out
            )
            .replace(R.id.fragment_container, VideoFragment())
            .commit()
    }

    // Меняет цвет кнопок: активная — розовая, неактивная — серая
    private fun setActiveButton(isPhotoActive: Boolean) {
        val primaryColor = getColor(R.color.primary)
        val grayColor = Color.parseColor("#9E9E9E")

        if (isPhotoActive) { // если активно фото
            photoButton.setBackgroundColor(primaryColor)
            videoButton.setBackgroundColor(grayColor)
        } else {
            photoButton.setBackgroundColor(grayColor)
            videoButton.setBackgroundColor(primaryColor)
        }
    }
}