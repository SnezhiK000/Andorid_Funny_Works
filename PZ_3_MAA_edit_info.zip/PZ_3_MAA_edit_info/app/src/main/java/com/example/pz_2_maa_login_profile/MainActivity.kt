package com.example.pz_2_maa_login_profile

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.*
class MainActivity : AppCompatActivity() {
    private val EDIT_PROFILE_REQUEST = 1 //показательная переменная на редактирование профиля

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() //включение режима рашсирения
        setContentView(R.layout.profile) // загружаю профиль (макет)

        val enterButton = findViewById<Button>(R.id.enter)  //поиск кнопки редактирования

        val fullNameText = findViewById<TextView>(R.id.fullName) // ищу все TextView, где отображается информация профиля
        val genderText = findViewById<TextView>(R.id.gender)
        val passText = findViewById<TextView>(R.id.pass)
        val experienceText = findViewById<TextView>(R.id.experience)
        val contactsText = findViewById<TextView>(R.id.contacts)

        updateProfileDisplay( //установка начального значения
            fullName = "Мальцева Анастасия Александровна",
            gender = "Женский",
            about = "Здесь будет информация о пользователе, его интересы, увлечения и краткое описание.",
            skills = "• Java и Kotlin разработка\n• Android разработка\n• UI/UX дизайн",
            email = "malcevanastya123@gmail.com",
            phone = "+7 (999) 999-99-99",
            city = "Москва"
        )

        enterToEditProfile(enterButton) //обработка нажатия на кнопку

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets -> //системные отступы
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun enterToEditProfile(button: Button) { //переход в редактор профиля
        button.setOnClickListener {

            val intent = Intent(this, EditProfileActivity::class.java) //intel для перехода в другую активность

            intent.putExtra("fullName", findViewById<TextView>(R.id.fullName).text.toString()) //передача данных что-бы не было пустот
            intent.putExtra("about", findViewById<TextView>(R.id.pass).text.toString().replace("О себе\n", ""))
            intent.putExtra("gender", findViewById<TextView>(R.id.gender).text.toString().replace("Пол: ", ""))
            intent.putExtra("email", "malcevanastya123@gmail.com")
            intent.putExtra("phone", "+7 (999) 999-99-99")

            startActivityForResult(intent, EDIT_PROFILE_REQUEST) //запуск редактора
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) { //если пользователь возвращается обратно
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == EDIT_PROFILE_REQUEST && resultCode == RESULT_OK) { //проверка что пользователь нажал на кнопку и сохранил
            val name = data?.getStringExtra("fullName") ?: "..." // Получаею обновлённые данные из Intent
            val about = data?.getStringExtra("about") ?: "..."
            val gender = data?.getStringExtra("gender") ?: "..."

            updateProfileDisplay( //отображаю новые данные
                fullName = name,
                gender = gender,
                about = about,
                skills = "• Java и Kotlin разработка\n• Android разработка\n• UI/UX дизайн",
                email = "malcevanastya123@gmail.com",
                phone = "+7 (999) 999-99-99",
                city = "Москва"
            )
        }
    }

    private fun updateProfileDisplay( //метод отображения новых данных
        fullName: String,
        gender: String,
        about: String,
        skills: String,
        email: String,
        phone: String,
        city: String
    ) {
        findViewById<TextView>(R.id.fullName).text = fullName
        findViewById<TextView>(R.id.birthDate).text = "Дата рождения: 11.03.2006" // не редактируется, в шаблоне задания ее нет, сохраняется как есть
        findViewById<TextView>(R.id.gender).text = "Пол: $gender"
        findViewById<TextView>(R.id.pass).text = "О себе\n$about"
        findViewById<TextView>(R.id.experience).text = "Навыки\n$skills"
        findViewById<TextView>(R.id.contacts).text = "Контакты\nEmail: $email\nТелефон: $phone\nГород: $city"
    }
}