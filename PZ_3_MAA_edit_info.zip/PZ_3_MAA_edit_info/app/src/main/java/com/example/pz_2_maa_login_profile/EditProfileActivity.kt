package com.example.pz_2_maa_login_profile

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.textfield.TextInputEditText
import android.widget.*

class EditProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.edit_profile) // прогружаю макет редактора

        val saveButton = findViewById<Button>(R.id.saveButton)  //поиск кнопок сохранени и сброса
        val resetButton = findViewById<Button>(R.id.resetButton)

        val fullNameInput = findViewById<TextInputEditText>(R.id.fullNameInput) //поиск полей
        val emailInput = findViewById<TextInputEditText>(R.id.emailInput)
        val phoneInput = findViewById<TextInputEditText>(R.id.phoneInput)
        val aboutInput = findViewById<TextInputEditText>(R.id.aboutInput)
        val genderGroup = findViewById<RadioGroup>(R.id.genderGroup)

        val currentName = intent.getStringExtra("fullName") ?: "Мальцева Анастасия Александровна" //получение данных из главной активити
        val currentEmail = intent.getStringExtra("email") ?: "malcevanastya123@gmail.com"
        val currentPhone = intent.getStringExtra("phone") ?: "+7 (999) 999-99-99"
        val currentAbout = intent.getStringExtra("about") ?: "Опытный разработчик"
        val currentGender = intent.getStringExtra("gender") ?: "Женский"

        fullNameInput.setText(currentName) //заполняю полученными данными
        emailInput.setText(currentEmail)
        phoneInput.setText(currentPhone)
        aboutInput.setText(currentAbout)

        when (currentGender) { // пол
            "Мужской" -> genderGroup.check(R.id.maleRadio)
            "Женский" -> genderGroup.check(R.id.femaleRadio)
            "Другой" -> genderGroup.check(R.id.otherRadio)
            else -> genderGroup.check(R.id.otherRadio) // по умолчанию все указаны как другие
        }

        saveButton.setOnClickListener { //работа кнопки сохранения
            val name = fullNameInput.text.toString() //получение всех данных полей
            val email = emailInput.text.toString()
            val phone = phoneInput.text.toString()
            val about = aboutInput.text.toString()
            val gender = when (genderGroup.checkedRadioButtonId) { //обработка выбора пола
                R.id.maleRadio -> "Мужской"
                R.id.femaleRadio -> "Женский"
                else -> "Другой"
            }

            val resultIntent = Intent() //инициирование Intel для передачи

            resultIntent.putExtra("fullName", name)
            resultIntent.putExtra("about", about)
            resultIntent.putExtra("gender", gender)
            setResult(RESULT_OK, resultIntent) //возвращение результата
            finish() //закрытие активити
        }

        resetButton.setOnClickListener { //сброс всего до начальных настроек
            fullNameInput.setText("Мальцева Анастасия Александровна")
            emailInput.setText("malcevanastya123@gmail.com")
            phoneInput.setText("+7 (999) 999-99-99")
            aboutInput.setText("Опытный разработчик с более чем 5 годами опыта...")
            genderGroup.check(R.id.femaleRadio)
        }
        // Отступы под панели
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(android.R.id.content)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}