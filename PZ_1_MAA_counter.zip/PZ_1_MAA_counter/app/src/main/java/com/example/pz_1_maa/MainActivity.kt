package com.example.pz_1_maa

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.Button
import android.widget.TextView
class MainActivity : AppCompatActivity() {
    private var count = 0 //переменная для хранения счетчика

    override fun onCreate(savedInstanceState: Bundle?) { //метод для создания обработчиков кнопок
        super.onCreate(savedInstanceState)
        enableEdgeToEdge() //растяжка панели под систему
        setContentView(R.layout.activity_main) // макет экрана из файла activity_main.xml

         //Здесь я нахожу элементы по их id
        val counterText = findViewById<TextView>(R.id.counter) // Текстовое поле для отображения счётчика
        val plusButton = findViewById<Button>(R.id.plus)       // увеличить
        val dropButton = findViewById<Button>(R.id.drop)       // сброс
        val minesButton = findViewById<Button>(R.id.mines)     // уменьшить


        plusButton.setOnClickListener { // нажатие на кнопку увеличения
            count++ //увеличиваю счетчик на 1
            counterText.text = count.toString() // обновление текста на экране
        }

        minesButton.setOnClickListener { // нажатие на кнопку уменьшения
            count--
            counterText.text = count.toString()
        }

        dropButton.setOnClickListener { // нажатие на кнопку сброса
            count = 0
            counterText.text = count.toString()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) {  // настройка отступов под системные панели
            v, insets -> val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }
}