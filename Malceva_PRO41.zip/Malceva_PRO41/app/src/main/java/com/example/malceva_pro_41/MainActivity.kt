package com.example.malceva_pro_41
import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import android.widget.Button

class MainActivity : AppCompatActivity() {

    //Инициализирую кнопки
    private lateinit var photoButton: Button
    private lateinit var videoButton: Button
    private lateinit var audioButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        photoButton = findViewById(R.id.saveButton)
        videoButton = findViewById(R.id.cancelButton)
        audioButton = findViewById(R.id.audioButton)

        // Сразу показываю фото при запуске
        showPhotoFragment()

        setActiveButton(true, false)

        // клики по кнопкам
        photoButton.setOnClickListener {
            showPhotoFragment()
            setActiveButton(true, false)  // фото активно
        }

        videoButton.setOnClickListener {
            showVideoFragment()
            setActiveButton(false, true)  // видео активно
        }

        audioButton.setOnClickListener {
            showAudioFragment()
            setActiveButton(false, false)  // аудио активно
        }
    }

    // Показывает фрагмент с фото + плавная анимация
    private fun showPhotoFragment() {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.fade_in,    // вход нового фрагмента
                android.R.anim.fade_out,   // выход старого фрагмента
                android.R.anim.fade_in,    // при возврате назад — вход
                android.R.anim.fade_out    // при возврате назад — выход
            )
            .replace(R.id.fragment_container, PhotoFragment())
            .commit()
    }


    // Показывает фрагмент с видео + плавная анимация
    private fun showVideoFragment() {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.fade_in,
                android.R.anim.fade_out,
                android.R.anim.fade_in,
                android.R.anim.fade_out
            )
            .replace(R.id.fragment_container, VideoFragment())
            .commit()
    }

    private fun showAudioFragment() {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.fade_in,    // вход нового фрагмента
                android.R.anim.fade_out,   // выход старого фрагмента
                android.R.anim.fade_in,    // при возврате назад — вход
                android.R.anim.fade_out    // при возврате назад — выход
            )
            .replace(R.id.fragment_container, AudioFragment())
            .commit()
    }

    // активная — розовая, неактивная — серая
    private fun setActiveButton(isPhotoActive: Boolean, isVideoActive: Boolean) {
        val primaryColor = getColor(R.color.primary)
        val grayColor = Color.parseColor("#9E9E9E")

        photoButton.setBackgroundColor(if (isPhotoActive) primaryColor else grayColor)
        videoButton.setBackgroundColor(if (isVideoActive) primaryColor else grayColor)

        // Аудио активно, если ни фото, ни видео не активны
        val isAudioActive = !isPhotoActive && !isVideoActive
        audioButton.setBackgroundColor(if (isAudioActive) primaryColor else grayColor)
    }
}